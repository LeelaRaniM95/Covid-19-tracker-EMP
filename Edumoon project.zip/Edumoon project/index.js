// import express 
const express = require('express');

//creating objects
const app = express () ;

//import path module
const path = require('path');
app.set('views', path.join(__dirname,'views'))
app.set('view engine','ejs');

app.use(express.static('public'));

const api = require('novelcovid');

app.get("/",(req,res)=>{
    res.render("home")
});

app.get("/SearchCountry",(req,res)=>{
    //res.render("Welcome to search country page")
    let searchedcountry= req.query.countries
    console.log(searchedcountry)
    api.countries({country:searchedcountry}).then((data)=>{
        console.log(data);
        if(data.hasOwnProperty('message')){
           res.render('error',{error_message:data.message})
        }else{
             res.render('results',{result_data: data, image_url:data.countryInfo.flag })

        }
    })
});
// listening port
api.settings({
    baseUrl: 'https://disease.sh' 
})





app.listen(3009,()=>{
    console.log(`looking for port 3000 `)
});